﻿using ADPortsEmployee.API.Hub.Interface;
using Microsoft.AspNetCore.SignalR;
 using System;
using System.Threading.Tasks;

namespace ADPortsEmployee.API.Hub
{
    public class BroadCastHub : Hub<IHubClient>
    {
        private readonly IUserConnectionManager _userConnectionManager;
        public BroadCastHub(IUserConnectionManager userConnectionManager)
        {
            _userConnectionManager = userConnectionManager;
        }
        public override Task OnConnectedAsync()
        {
             var httpContext = this.Context.GetHttpContext();
             _userConnectionManager.KeepUserConnection(Convert.ToInt64(Context.UserIdentifier), Context.ConnectionId);
            return base.OnConnectedAsync();
        }
         public override async Task OnDisconnectedAsync(Exception exception)
        {
            //get the connectionId
            var connectionId = Context.ConnectionId;
            _userConnectionManager.RemoveUserConnection(connectionId);
            var value = await Task.FromResult(0);//adding dump code to follow the template of Hub > OnDisconnectedAsync
        }
    }
}
