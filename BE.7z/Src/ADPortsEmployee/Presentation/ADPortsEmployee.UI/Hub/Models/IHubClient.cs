﻿using System.Threading.Tasks;

namespace ADPortsEmployee.API.Hub
{
    public interface IHubClient
    {
        Task BroadcastMessage(string message);
     }
}
