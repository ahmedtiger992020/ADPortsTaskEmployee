﻿ using System.Collections.Generic;

namespace ADPortsEmployee.API.Hub.Interface
{
    public interface IUserConnectionManager
    {
        void KeepUserConnection(long userId, string connectionId);
        void RemoveUserConnection(string connectionId);
        List<string> GetUserConnections(long userId);
         List<string> GetActiveUserConnection(List<long> users);
    }
}