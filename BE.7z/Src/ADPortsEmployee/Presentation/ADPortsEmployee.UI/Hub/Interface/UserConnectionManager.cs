﻿ using System.Collections.Generic;
using System.Linq;

namespace ADPortsEmployee.API.Hub.Interface
{
    public class UserConnectionManager : IUserConnectionManager
    {
        private static Dictionary<long, List<ActiveUserDto>> userConnectionMap = new Dictionary<long, List<ActiveUserDto>>();
        private static string userConnectionMapLocker = string.Empty;

        public void KeepUserConnection(long token,
            string connectionId)
        {
            lock (userConnectionMapLocker)
            {
                if (!userConnectionMap.ContainsKey(token))
                {
                    userConnectionMap[token] = new List<ActiveUserDto>();
                }
                else
                {
                    userConnectionMap[token].RemoveAll(v => v.ConnectionId != default);
                }
                userConnectionMap[token].Add(new ActiveUserDto() { ConnectionId = connectionId });
            }
        }

        public void RemoveUserConnection(string connectionId)
        {
            //Remove the connectionId of user 
            lock (userConnectionMapLocker)
            {
                foreach (var userId in userConnectionMap.Keys)
                {
                    if (userConnectionMap.ContainsKey(userId))
                    {
                        if (userConnectionMap[userId].Select(v => v.ConnectionId).Contains(connectionId))
                        {
                            userConnectionMap[userId].RemoveAll(s => s.ConnectionId == connectionId);
                            break;
                        }
                    }
                }
            }
        }
        public List<string> GetUserConnections(long token)
        {
            var conn = new List<string>();
            lock (userConnectionMapLocker)
            {
                conn = userConnectionMap[token].Select(v => v.ConnectionId).ToList();
            }
            return conn;
        }

        public List<string> GetActiveUserConnection(List<long> users)
        {
            var conn = new List<string>();
            if (users?.Any() ?? default)
            {
                users.ForEach(v =>
                {
                    if (userConnectionMap.ContainsKey(v))
                    {
                        conn.AddRange(userConnectionMap[v].Select(v => v.ConnectionId));
                    }
                });
            }
            return conn;

        }
    }

    internal class ActiveUserDto
    {
        public string ConnectionId { get; set; }
 
    }
}