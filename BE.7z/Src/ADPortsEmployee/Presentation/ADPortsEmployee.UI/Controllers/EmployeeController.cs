﻿
using ADPortsEmployee.DTO;
using ADPortsEmployee.UI.ServicesLayer.EmployeeService;
using ADPortsEmployee.SharedKernel.Uploader;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace ADPortsEmployee.API.UI.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    [Authorize]
    public class EmployeeController : ControllerBase
    {
        private readonly ILogger<EmployeeController> _logger;
        private readonly IEmployeeService _employeeService;
        public IConfiguration Configuration { get; }
        public EmployeeController(ILogger<EmployeeController> logger, IEmployeeService employeeService, IConfiguration configuration)
        {
            _logger = logger;
            _employeeService = employeeService;
            Configuration = configuration;
        }

        /// <summary>
        /// Create New Employee
        /// </summary>
        /// <param name="Employee"> Employee Dto</param>
        /// <returns>True if Added otherwise False</returns>
        [HttpPost]
        public async Task<ActionResult<ApiResponse<bool>>> CreateEmployee(CreateEmployeeDto request)
        {
            return Ok(await _employeeService.CreateEmployee(request));
        }
        /// <summary>
        /// Update Employee Data stored and found in our db
        /// </summary>
        /// <param name="Employee">Employee New Data and its id </param>
        /// <returns>True if Updated otherwise False</returns>
        [HttpPost]
        public async Task<ActionResult<ApiResponse<bool>>> UpdateEmployee(UpdateEmployeeDto request)
        {
            return Ok(await _employeeService.UpdateEmployee(request));
        }


        /// <summary>
        /// Get Employee Detail by its id 
        /// </summary>
        /// <param name="EmployeeId">employee Id</param>
        /// <returns>Employee Object details </returns>
        [HttpGet]
        public async Task<ActionResult<ApiResponse<GetEmployeeDetailDto>>> GetEmployeeById(int requestId)
        {
            return Ok(await _employeeService.GetEmployeeById(requestId));
        }

        /// <summary>
        /// Remove Employee By its id
        /// </summary>
        /// <param name="requestId">true if remove otherwise fasle</param>
        /// <returns></returns>
        [HttpPost]
        public async Task<ActionResult<ApiResponse<bool>>> DeleteEmployee(int requestId)
        {
            return Ok(await _employeeService.DeleteEmployee(requestId));
        }

        /// <summary>
        /// Get All Employee in the System 
        /// </summary>
        /// <param name="Employee">Get paging and sorting if found Model or search Crititeria</param>
        /// <returns>List of Employee based on input page size or number</returns>
        [HttpPost]
        public async Task<ActionResult<PageList<List<GetAllEmployeeOutputDto>>>> GetAllEmployee(GetAllEmployeeInputDto request)
        {
            return Ok(await _employeeService.GetAll(request));
        }


        #region private methods
        /// <summary>
        /// check if uploaded file has valid format/extension
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        private bool IsValidFormat(string fileName)
        {
            var extenstions = fileName.Split('.');
            if (extenstions == default || extenstions.Length == default(byte)) return default;
            string fileFormat = extenstions[extenstions.Length - 1].Trim().ToLower();
            string[] validFormats = Configuration.GetSection("AllowedFormats").AsEnumerable().Where(s => s.Value != null).Select(a => a.Value).ToArray();
            return validFormats.Contains(fileFormat);
        }

        /// <summary>
        /// return content type for file
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="file"></param>
        /// <returns></returns>
        private string GetMimeType(string fileName, IFormFile file)
        {
            using (var ms = new MemoryStream())
            {
                file.CopyTo(ms);
                var fileBytes = ms.ToArray();
                return MimeType.GetMimeType(fileBytes, fileName);
            }
        }
        /// <summary>
        /// check if uploaded file has valid mime type
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="file"></param>
        /// <returns></returns>
        private bool ValidateMimeType(string fileName, IFormFile file)
        {
            string mimiType = GetMimeType(fileName, file);

            string validExtension = "application/x-zip-compressed";
            if (validExtension.Any())
                return validExtension.Trim().ToLower().Equals(mimiType);
            return true;
        }
        #endregion

    }
}
