﻿
using ADPortsEmployee.API.Hub;
using ADPortsEmployee.API.Hub.Interface;
using ADPortsEmployee.DTO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Logging;

using System.Collections.Generic;
using System.Threading.Tasks;

namespace ADPortsEmployee.API.UI.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
     public class NotificationController : ControllerBase
    {
        private readonly ILogger<NotificationController> _logger;
        private readonly IHubContext<BroadCastHub, IHubClient> _notificationHubContext;
        private readonly IUserConnectionManager _userConnectionManager;


        public NotificationController(ILogger<NotificationController> logger, IHubContext<BroadCastHub, IHubClient> hubContext, IUserConnectionManager userConnectionManager)
        {
            _logger = logger;
            _notificationHubContext = hubContext;
            _userConnectionManager = userConnectionManager;
         
        }


        [HttpPost]
        public async Task<ActionResult<ApiResponse<bool>>> ChangeRequestStatus(List<long> users)
        {
            var connections = _userConnectionManager.GetActiveUserConnection(users);
            if (connections != null && connections.Count > 0)
            {
                foreach (var connectionId in connections)
                {
                    await _notificationHubContext.Clients.Client(connectionId).BroadcastMessage("Employee Is Added");
                }
            }
            return Ok();
        }

    }
}
