﻿using ADPortsEmployee.DTO;
using ADPortsEmployee.UI.ServicesLayer.UserService;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
  using System.Threading.Tasks;

namespace ADPortsEmployee.API.UI.Controllers
{
    [ApiController]
    [Authorize]
    [Route("api/[controller]/[action]")]
    public class UserController : ControllerBase
    {
        private readonly IUserService UserService;

        public UserController(IUserService userService)
        {
            UserService = userService;
        }
 
        /// <summary>
        /// Generate App Token And Login 
        /// </summary>
        /// <returns>Jwt Token</returns>
        [HttpPost]
        [AllowAnonymous]
        public async Task<ActionResult<ApiResponse<string>>> Login(LoginRequestDto request)

        {
            var token = await UserService.GenerateAppToken(request);
            if (string.IsNullOrWhiteSpace(token))
                return Unauthorized("Invalid UserName or Password");

           
            return Ok(new ApiResponse<string>(token, "LoginSuccess", true));
        }
 
    }
}
