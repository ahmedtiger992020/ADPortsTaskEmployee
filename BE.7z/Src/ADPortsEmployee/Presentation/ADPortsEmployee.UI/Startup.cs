using ADPortsEmployee.DTO;
using ADPortsEmployee.UI.ServicesLayer.EmployeeService;
using ADPortsEmployee.UI.ServicesLayer.Mapping;
using ADPortsEmployee.SharedKernel.GenericApiCall;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using RepositoryLayer.Context;
using RepositoryLayer.Repository.IRepo;
using RepositoryLayer.Repository.Repo;
using RepositoryLayer.UnitOfWork;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using ADPortsEmployee.API.Hub.Interface;
using ADPortsEmployee.API.Hub;

namespace ADPortsEmployee.API.UI
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        private string AllowedOrigins { get; } = "AllowedOrigins";
        public IConfiguration Configuration { get; }


        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddSingleton(Log.Logger);
            services.AddControllers();
            services.AddAuthentication();

            #region AutoMapper
            services.AddAutoMapper(typeof(EmployeeMapping).Assembly);
            #endregion

            #region Swagger
            services.AddSwaggerGen(c =>
         {
             c.SwaggerDoc("ADPorts-API", new OpenApiInfo { Title = "ADPortsEmployee.API", Version = "v1" });
             c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
             {
                 Description = @"JWT Authorization header using the Bearer scheme. \r\n\r\n 
                      Enter 'Bearer' [space] and then your token in the text input below.
                      \r\n\r\nExample: 'Bearer 12345abcdef'",
                 Name = "Authorization",
                 In = ParameterLocation.Header,
                 Type = SecuritySchemeType.ApiKey,
                 Scheme = "Bearer"
             });

             c.DescribeAllParametersInCamelCase();
             c.AddSecurityRequirement(new OpenApiSecurityRequirement()
                  {
                    {
                      new OpenApiSecurityScheme
                      {
                        Reference = new OpenApiReference
                          {
                            Type = ReferenceType.SecurityScheme,
                            Id = "Bearer"
                          },
                          Scheme = "oauth2",
                          Name = "Bearer",
                          In = ParameterLocation.Header,

                        },
                        new List<string>()
                      }
                    });
         });



            #endregion

            #region CorsOrigin

            services.AddCors(o => o.AddDefaultPolicy(builder =>
           {
               builder.WithOrigins("http://localhost:4200")
                      .AllowAnyMethod()
                      .AllowAnyHeader()
                      .AllowCredentials();
           }));
            #endregion

            #region Context
            services.AddDbContext<ApplicationDbContext>(options =>
            {
                options.UseLoggerFactory(LoggerFactory.Create(builder => builder.AddConsole()));

                options.UseSqlServer(Configuration.GetConnectionString("Default"),
                    sqlServerOptionsAction: sqlOptions =>
                    {
                        sqlOptions.MigrationsAssembly(typeof(Startup).GetTypeInfo().Assembly.GetName().Name);
                        sqlOptions.EnableRetryOnFailure(maxRetryCount: 15, maxRetryDelay: TimeSpan.FromSeconds(30), errorNumbersToAdd: null);
                    });
            },
                      ServiceLifetime.Scoped  //Showing explicitly that the DbContext is shared across the HTTP request scope (graph of objects started in the HTTP request)
                      );

            #endregion

            #region Settings 
            var tokenSettings = new TokenSettings();
            Configuration.Bind("JWTSettings", tokenSettings);
            services.AddSingleton(tokenSettings);
            var appSetting = new AppSetting();
            Configuration.Bind("AppSetting", appSetting);
            services.AddSingleton(appSetting);
            #endregion

            #region Repo
            Type[] repositories = Assembly.Load(typeof(EmployeeRepo).Assembly.GetName()).GetTypes().Where(r => r.Name.EndsWith("Repo")).ToArray();
            Type[] iRepositories = Assembly.Load(typeof(IEmployeeRepo).Assembly.GetName()).GetTypes().Where(r => r.IsInterface && r.Name.EndsWith("Repo")).ToArray();
            foreach (var repoInterface in iRepositories)
            {
                System.Type classType = repositories.FirstOrDefault(r => repoInterface.IsAssignableFrom(r));
                if (classType != null)
                {
                    services.AddScoped(repoInterface, classType);
                }
            }
            #endregion

            #region UOF
            services.AddScoped(typeof(IUnitOfWork), typeof(UnitOfWork));
            #endregion

            #region TokenHandler
            services.AddScoped<ADPortsEmployee.SharedKernel.TokenHelper.TokenHandler>();
            #endregion

            #region HttpContextAccessor
            services.AddHttpContextAccessor();
            #endregion

            #region Services
            Type[] appServices = Assembly.Load(typeof(EmployeeService).Assembly.GetName()).GetTypes().Where(r => r.IsClass && r.Name.EndsWith("Service")).ToArray();
            Type[] iappServices = Assembly.Load(typeof(IEmployeeService).Assembly.GetName()).GetTypes().Where(r => r.IsInterface && r.Name.EndsWith("Service")).ToArray();
            foreach (var serviceInterface in iappServices)
            {
                System.Type classType = appServices.FirstOrDefault(r => serviceInterface.IsAssignableFrom(r));
                if (classType != null)
                {
                    services.AddScoped(serviceInterface, classType);
                }
            }
            services.AddScoped<IGenericApiCall, GenericAPICall>();

            #endregion

            services.AddSingleton<IUserConnectionManager, UserConnectionManager>();

            #region JWT

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(options =>
            {
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    ValidIssuer = Configuration["JWTSettings:Issuer"],
                    ValidAudience = Configuration["JWTSettings:Audience"],
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["JWTSettings:SecretKey"]))
                };
                options.Events = new JwtBearerEvents
                {
                    OnMessageReceived = context =>
                    {
                        var accessToken = context.Request.Query["access_token"];
                        var path = context.HttpContext.Request.Path;
                        if (!string.IsNullOrEmpty(accessToken) && (path.StartsWithSegments("/notify")))
                        {
                            context.Token = accessToken;
                        }
                        return Task.CompletedTask;
                    }
                };
            });

            #endregion

            #region CORS
            List<string> origns = new List<string>();

            IConfigurationSection originsSection = Configuration.GetSection("AllowedOrigins");
            string[] appSettingOrigns = originsSection.AsEnumerable().Where(s => s.Value != null).Select(a => a.Value).ToArray();

            foreach (string k in appSettingOrigns)
            {
                origns.AddRange(k.Split(",").ToList());
            }

            //Log.Warning($"Origins: {string.Join(" , ", origns)}");

            services.AddCors(options =>
            {
                options.AddPolicy(AllowedOrigins,
                    builder =>
                    {
                        builder.WithOrigins(origns.ToArray())
                               .AllowAnyMethod()
                               .AllowAnyHeader()
                               .AllowCredentials();
                    });
            });
            #endregion

            services.AddSignalR();


        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseSwagger();
            app.UseSwaggerUI(c => c.SwaggerEndpoint(Configuration.GetSection("AppSetting").GetSection("SwaggerPath").Value, "ADPorts-API"));

            app.UseAppMiddleware();

            #region CORS
            app.UseCors(AllowedOrigins);
            #endregion
            app.UseHttpsRedirection();
            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapHub<BroadCastHub>("/notify");

            });
        }
    }
}
