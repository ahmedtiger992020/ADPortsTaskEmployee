﻿namespace ServicesLayer.Dto
{
    public class LoginResponseDto
    {
        public string Token { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public bool IsAdmin { get; set; }
        //public List<AppDto> App { get; set; }
    }
}
