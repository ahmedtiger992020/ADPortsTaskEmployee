﻿namespace ServicesLayer.Dto.Common
{
    public class DDLDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
