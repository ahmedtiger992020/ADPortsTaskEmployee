﻿using ADPortsEmployee.DTO;
using ADPortsEmployee.UI.DomainLayer.Models;
using System;

namespace ADPortsEmployee.UI.ServicesLayer.Mapping
{
    public class EmployeeMapping : AutoMapper.Profile
    {
        public EmployeeMapping()
        {
            CreateMap<Employee, CreateEmployeeDto>()
                 .ReverseMap()
               .ForMember(dest => dest.CreatedDate, y => y.MapFrom(x => DateTime.UtcNow));

            CreateMap<Employee, UpdateEmployeeDto>()
               .ReverseMap()
               .ForMember(dest => dest.ModifiedDate, y => y.MapFrom(x => DateTime.UtcNow))
               .ForMember(dest => dest.CreatedDate, y => y.Ignore());


            CreateMap<Employee, GetAllEmployeeOutputDto>()
               .ForMember(dest => dest.CreatedDate, y => y.MapFrom(x => x.CreatedDate.ToString("yyyy-MM-dd")))
                .ReverseMap();


            CreateMap<Employee, GetEmployeeDetailDto>()
            .ReverseMap();

        }

    }
}
