﻿
using ADPortsEmployee.DTO;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ADPortsEmployee.UI.ServicesLayer.UserService
{
    public interface IUserService
    {
        Task<string> GenerateAppToken(LoginRequestDto request);
    }
}
