﻿using ADPortsEmployee.DTO;
using ADPortsEmployee.SharedKernel.TokenHelper;
using ADPortsEmployee.UI.ServicesLayer.Services.BaseService;
using AutoMapper;
using Microsoft.AspNetCore.Http;

using RepositoryLayer.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace ADPortsEmployee.UI.ServicesLayer.UserService
{
    public class UserService : BaseAppService, IUserService
    {
        #region CTOR
        public UserService(IHttpContextAccessor httpContextAccesso,
            IUnitOfWork unitOfWork, IMapper mapper, TokenSettings tokenSettings, TokenHandler tokenHandler, AppSetting appSetting) :
            base(httpContextAccesso, unitOfWork, mapper)
        {
            TokenSettings = tokenSettings;
            TokenHandler = tokenHandler;
            AppSetting = appSetting;
        }
        #endregion

        #region Props 
        public TokenSettings TokenSettings { get; }
        public TokenHandler TokenHandler { get; }
        public AppSetting AppSetting { get; }

        #endregion

        #region Public Methods
        public async Task<string> GenerateAppToken(LoginRequestDto request)
        {
            if (string.IsNullOrWhiteSpace(request.UserName) || string.IsNullOrWhiteSpace(request.Password) || !AppSetting.UserName.Equals(request.UserName) || !AppSetting.Password.Equals(request.Password))
                return string.Empty;
            return TokenHandler.GenerateToken(1, TokenSettings.SecretKey, TokenSettings.Audience, TokenSettings.DurationInMinutes, TokenSettings.Issuer);
        }

        #endregion
    }

}
