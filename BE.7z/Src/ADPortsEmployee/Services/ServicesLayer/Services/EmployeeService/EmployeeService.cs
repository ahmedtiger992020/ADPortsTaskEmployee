﻿using ADPortsEmployee.DTO;
using ADPortsEmployee.UI.DomainLayer.Models;
using ADPortsEmployee.UI.ServicesLayer.Services.BaseService;
using ADPortsEmployee.SharedKernel.Exceptions;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using RepositoryLayer.Repository.IRepo;
using RepositoryLayer.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace ADPortsEmployee.UI.ServicesLayer.EmployeeService
{
    public class EmployeeService : BaseAppService, IEmployeeService
    {
        #region CTOR
        public EmployeeService(IUnitOfWork unitOfWork, IMapper mapper, IHttpContextAccessor httpContextAccesso, IEmployeeRepo employeeRepo)
            : base(httpContextAccesso, unitOfWork, mapper)
        {
            EmployeeRepo = employeeRepo;
        }
        #endregion

        #region Props
        public IEmployeeRepo EmployeeRepo { get; }

        #endregion

        #region Methods

        /// <summary>
        /// Create New Employee
        /// </summary>
        /// <param name="Employee"> Employee Dto</param>
        /// <returns>True if Added otherwise False</returns>
        public async Task<ApiResponse<bool>> CreateEmployee(CreateEmployeeDto request)
        {
            #region Declare Return Value
            ApiResponse<bool> response = new ApiResponse<bool>();
            #endregion

            #region Validation Of input Dto
            await IsValidInput(request);
            #endregion

            var obj = Mapper.Map<Employee>(request);

            await EmployeeRepo.InsertAsync(obj);

            bool isSuccess = await UnitOfWork.SaveChangesAsync();
            if (isSuccess)
            {
                await UnitOfWork.SaveChangesAsync();
                response.IsValidResponse = true;
                response.CommandMessage = "Employee Data Added Successfully ";
            }
            else
            {
                response.CommandMessage = "Failed to Update the new Employee. Try again shortly.";
            }
            return response;

        }
        /// <summary>
        /// Update Employee Data stored and found in our db
        /// </summary>
        /// <param name="Employee">Employee New Data and its id </param>
        /// <returns>True if Updated otherwise False</returns>
        public async Task<ApiResponse<bool>> UpdateEmployee(UpdateEmployeeDto request)
        {
            #region Declare Return Value
            ApiResponse<bool> response = new ApiResponse<bool>();
            #endregion
            #region Validation Of input Dto
            await IsValidEdit(request);
            #endregion

            var currentEmployee = await EmployeeRepo.GetFirstOrDefaultAsync(a => a.Id == request.Id);

            #region Validate Current Employee
            if (currentEmployee == default)
            {
                response.CommandMessage = "This Employee Not Exist To Update his data";
                return response;
            }

            #endregion

            #region Another Mapping For Object

            currentEmployee.Name = request.Name;
            currentEmployee.Address = request.Address;
            currentEmployee.Contact = request.Contact;
            currentEmployee.Manager = request.Manager;
             currentEmployee.ModifiedDate = DateTime.UtcNow;
            #endregion

            #region Updating and Saving into DB
            EmployeeRepo.Update(currentEmployee);

            bool isSuccess = await UnitOfWork.SaveChangesAsync();
            if (isSuccess)
            {
                response.IsValidResponse = true;
                response.CommandMessage = $"Employee {currentEmployee.Name} is Updated Successfully";
            }
            else
            {
                response.IsValidResponse = false;
                response.CommandMessage = "Failed to Update the Employee. Try again shortly.";
            }
            #endregion
            return response;
        }

        /// <summary>
        /// Soft Delete Employee
        /// </summary>
        /// <param name="EmployeeId">Employee Id</param>
        /// <returns>True if Added otherwise False</returns>
        public async Task<ApiResponse<bool>> DeleteEmployee(int employeeId)
        {
            #region Declare Return Value
            ApiResponse<bool> response = new ApiResponse<bool>();
            #endregion

            var currentEmployee = await EmployeeRepo.GetFirstOrDefaultAsync(a => a.Id == employeeId);

            #region Validate Current Employee
            if (currentEmployee == default)
            {
                response.CommandMessage = "This Employee Not Exist To Delete";
                return response;
            }
            #endregion
            currentEmployee.IsDeleted = true;

            #region Saving into DB
            EmployeeRepo.Update(currentEmployee);

            bool isSuccess = await UnitOfWork.SaveChangesAsync();
            if (isSuccess)
            {
                response.IsValidResponse = true;
                response.CommandMessage = $"Employee {currentEmployee.Name} is Deleted Successfully";
            }
            else
            {
                response.IsValidResponse = false;
                response.CommandMessage = "Failed to Delete the Employee. Try again shortly.";
            }
            #endregion
            return response;
        }

        /// <summary>
        /// Get All Employee in the System 
        /// </summary>
        /// <param name="Employee">Get paging and sorting if found Model or search Crititeria</param>
        /// <returns>List of Employee based on input page size or number</returns>
        public async Task<PageList<GetAllEmployeeOutputDto>> GetAll(GetAllEmployeeInputDto request)
        {
            PageList<GetAllEmployeeOutputDto> response = new();



            #region Filter
            Expression<Func<Employee, bool>> filter = x =>
                     (string.IsNullOrEmpty(request.Name) || x.Name.Contains(request.Name.Trim()))
                   && (string.IsNullOrEmpty(request.Address) || x.Address.Contains(request.Address.Trim()))
                   && (string.IsNullOrEmpty(request.Manager) || x.Manager.Contains(request.Manager.Trim()))
                   && (string.IsNullOrEmpty(request.DateFrom) || x.CreatedDate.Date >= DateTime.Parse(request.DateFrom))
                   && (string.IsNullOrEmpty(request.DateTo) || x.CreatedDate.Date <= DateTime.Parse(request.DateTo));

            #endregion


            //Sorting Expressions to Handle Sorting from UI
            #region Sorting
            Expression<Func<Employee, string>> sorting = null;
            switch (request.SortingModel.SortingExpression)
            {
                case "EmployeeName": sorting = s => s.Name; break;
                case "EmployeeAddress": sorting = s => s.Address.ToString(); break;
                case "SubmissionDate": sorting = s => s.CreatedDate.ToString(); break;
                case "Manager": sorting = s => s.Manager.ToString(); break;
                case "Contact": sorting = s => s.Contact.ToString(); break;
                default: sorting = s => s.Name; break;
            }
            #endregion

            #region GetData From DB
            var listDb = await EmployeeRepo.GetPageAsync(request.Paging.Page, request.Paging.PageSize, filter, sorting, request.SortingModel.SortingDirection);
            var totalCount = await EmployeeRepo.GetCountAsync(filter);

            if (listDb?.Any() ?? default)
                response.SetResult(totalCount, Mapper.Map<List<GetAllEmployeeOutputDto>>(listDb));

            #endregion
            return response;

        }
        /// <summary>
        /// Get Employee Detail by its id 
        /// </summary>
        /// <param name="EmployeeId">employee Id</param>
        /// <returns>Employee Object details </returns>
        public async Task<ApiResponse<GetEmployeeDetailDto>> GetEmployeeById(int employeeId)
        {
            #region GetEmployee From DB
            var currentRequest = await EmployeeRepo.GetFirstOrDefaultAsync(a => a.Id == employeeId);
            if (currentRequest != default)
                return new ApiResponse<GetEmployeeDetailDto>(Mapper.Map<GetEmployeeDetailDto>(currentRequest), "", true);

            #endregion

            return new ApiResponse<GetEmployeeDetailDto>(default, "No DataFound", true);

        }
        #endregion

        #region Private Methods
        private async Task<bool> IsValidInput(CreateEmployeeDto request)
        {
            if (string.IsNullOrWhiteSpace(request.Name))
                throw new ValidationsException("Employee Name Is Required");

            if (string.IsNullOrWhiteSpace(request.Address))
                throw new ValidationsException("Address Is Required");

            if (string.IsNullOrWhiteSpace(request.Contact))
                throw new ValidationsException("Employee Contact Is Required");
 

            return true;
        }
        private async Task<bool> IsValidEdit(UpdateEmployeeDto request)
        {

            if (request.Id == default)
                throw new ValidationsException("Employee Id Is Required");

            if (string.IsNullOrWhiteSpace(request.Name))
                throw new ValidationsException("Employee Name Is Required");

            if (string.IsNullOrWhiteSpace(request.Address))
                throw new ValidationsException("Address Is Required");

            if (string.IsNullOrWhiteSpace(request.Contact))
                throw new ValidationsException("Employee Contact Is Required");

 

            return true;
        }

        #endregion
    }
}
