﻿using ADPortsEmployee.DTO;
using System.Threading.Tasks;

namespace ADPortsEmployee.UI.ServicesLayer.EmployeeService
{
    public interface IEmployeeService
    {

        Task<ApiResponse<bool>> CreateEmployee(CreateEmployeeDto request);
        Task<ApiResponse<bool>> UpdateEmployee(UpdateEmployeeDto request);
        Task<ApiResponse<GetEmployeeDetailDto>> GetEmployeeById(int employeeId);
        Task<ApiResponse<bool>> DeleteEmployee(int employeeId);
        Task<PageList<GetAllEmployeeOutputDto>> GetAll(GetAllEmployeeInputDto request);

    }
}
