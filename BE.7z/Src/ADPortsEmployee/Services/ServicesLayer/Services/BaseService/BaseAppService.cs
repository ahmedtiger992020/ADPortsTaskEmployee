﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using RepositoryLayer.UnitOfWork;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;

namespace ADPortsEmployee.UI.ServicesLayer.Services.BaseService
{
    public class BaseAppService
    {
        #region Props
        public IHttpContextAccessor HttpContextAccessor { get; }
        public IUnitOfWork UnitOfWork { get; }
        public IMapper Mapper { get; }

        #endregion

        #region Ctor
        public BaseAppService(IHttpContextAccessor httpContextAccesso, IUnitOfWork unitOfWork, IMapper mapper)
        {
            HttpContextAccessor = httpContextAccesso;
            UnitOfWork = unitOfWork;
            Mapper = mapper;
        }

        #endregion

        #region Method
        private string GetClaim(string token, string claimType)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var securityToken = new JwtSecurityToken(token);// tokenHandler.ReadToken(token) as JwtSecurityToken;

            var stringClaimValue = securityToken.Claims.First(claim => claim.Type == claimType).Value;
            return stringClaimValue;
        }
        #endregion
    }

}
