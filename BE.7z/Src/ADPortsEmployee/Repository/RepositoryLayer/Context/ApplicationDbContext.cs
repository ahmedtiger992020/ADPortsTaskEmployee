﻿using ADPortsEmployee.UI.DomainLayer.Configuration;
using ADPortsEmployee.UI.DomainLayer.Models;
using Microsoft.EntityFrameworkCore;

namespace RepositoryLayer.Context
{
    public class ApplicationDbContext : DbContext
    {
        #region Props
        public virtual DbSet<Employee> Employee { get; set; }
        #endregion


        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfigurationsFromAssembly(typeof(EmployeeConfiguration).Assembly);
            base.OnModelCreating(modelBuilder);

        }

    }


}
