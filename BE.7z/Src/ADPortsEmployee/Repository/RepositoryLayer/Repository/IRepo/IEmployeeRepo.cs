﻿using ADPortsEmployee.UI.DomainLayer.Models;

namespace RepositoryLayer.Repository.IRepo
{
    public interface IEmployeeRepo : IRepository<Employee>
    {
    }
}
