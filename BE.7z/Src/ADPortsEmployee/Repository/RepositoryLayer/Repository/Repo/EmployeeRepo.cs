﻿using ADPortsEmployee.UI.DomainLayer.Models;
using Microsoft.EntityFrameworkCore;
using RepositoryLayer.Context;
using RepositoryLayer.Repository.BaseRepository;
using RepositoryLayer.Repository.IRepo;

namespace RepositoryLayer.Repository.Repo
{
    public class EmployeeRepo : Repository<Employee>, IEmployeeRepo
    {
        private DbSet<Employee> entity;
        #region Constructor  
        public EmployeeRepo(ApplicationDbContext context) : base(context)
        {
            entity = context.Set<Employee>();
        }
        #endregion



    }
}
