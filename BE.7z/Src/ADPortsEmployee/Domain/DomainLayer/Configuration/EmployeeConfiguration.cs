﻿using ADPortsEmployee.UI.DomainLayer.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ADPortsEmployee.UI.DomainLayer.Configuration
{
    public class EmployeeConfiguration : IEntityTypeConfiguration<Employee>
    {
        public void Configure(EntityTypeBuilder<Employee> entity)
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Id).ValueGeneratedOnAdd();
            entity.Property(e => e.Name).HasMaxLength(256);
            entity.Property(e => e.Address).HasMaxLength(2084);
            entity.Property(e => e.Manager).HasMaxLength(256);
            entity.Property(e => e.Contact).HasMaxLength(256);
 
            entity.HasQueryFilter(x => x.IsDeleted == false);

        }
    }
}
