﻿namespace ADPortsEmployee.UI.DomainLayer.Models
{
    public class Employee : BaseEntity
    {
        #region Props
        public string Name { get; set; }
        public string Address { get; set; }
        public string Manager { get; set; }
        public string Contact { get; set; }
         #endregion
    }
}
