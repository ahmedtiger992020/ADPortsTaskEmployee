﻿
using System.ComponentModel.DataAnnotations;

namespace ADPortsEmployee.DTO
{
    public class GetAllEmployeeInputDto
    {
        #region Properties
        public PagingModel Paging { get; set; }
        public SortingModel SortingModel { get; set; }
        #endregion
        [MaxLength(256)]
        public string Name { get; set; }
        public string Address { get; set; }
        public string Manager { get; set; }
        public string Contact { get; set; }
        public string DateFrom { get; set; }
        public string DateTo { get; set; }

    }
}
