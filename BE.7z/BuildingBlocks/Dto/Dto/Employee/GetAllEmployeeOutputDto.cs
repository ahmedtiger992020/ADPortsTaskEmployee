﻿
namespace ADPortsEmployee.DTO
{
    public class GetAllEmployeeOutputDto : IdDto
    {
        #region Prop
        public string Name { get; set; }
        public string Address { get; set; }
        public string Manager { get; set; }
        public string Contact { get; set; }
        public string CreatedDate { get; set; }
         #endregion
    }
}
