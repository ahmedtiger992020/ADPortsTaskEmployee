﻿namespace ADPortsEmployee.DTO
{
    public class UpdateEmployeeDto : IdDto
    {
        public string Name { get; set; }
        public string Address { get; set; }
        public string Manager { get; set; }
        public string Contact { get; set; }
 
    }
}
