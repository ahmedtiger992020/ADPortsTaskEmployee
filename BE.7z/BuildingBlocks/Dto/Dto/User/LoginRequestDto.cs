﻿using System.ComponentModel.DataAnnotations;

namespace ADPortsEmployee.DTO
{
    public class LoginRequestDto
    {
        [MaxLength(128)]

        public string UserName { get; set; }
        [MaxLength(128)]

        public string Password { get; set; }
    }
}
