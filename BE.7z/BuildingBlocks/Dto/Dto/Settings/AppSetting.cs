﻿namespace ADPortsEmployee.DTO
{
    public class AppSetting
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}
