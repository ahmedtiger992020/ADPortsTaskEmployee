﻿namespace ADPortsEmployee.DTO
{
    public class StaticFileSetting
    {
        public string ServerPath { get; set; }
        public string StaticFolderPath { get; set; }
    }
}
