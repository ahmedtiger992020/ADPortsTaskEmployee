﻿using System.Linq;

namespace ADPortsEmployee.DTO.Enums
{

    public static class ExtensionMethods
    {
        /// <summary>
        /// To get enum string value
        /// </summary>
        /// <param name="value"></param>
        /// <returns>string</returns>
        public static string GetDescription(this System.Enum value)
        {
            EnumMessage descriptionAttribute = (EnumMessage)value.GetType().GetField(value.ToString()).GetCustomAttributes(false).Where(a => a is EnumMessage).FirstOrDefault();
            return descriptionAttribute != null ? descriptionAttribute.Message : value.ToString();
        }
        public static string GetDetails(this System.Enum value)
        {
            EnumMessage descriptionAttribute = (EnumMessage)value.GetType().GetField(value.ToString()).GetCustomAttributes(false).Where(a => a is EnumMessage).FirstOrDefault();
            return descriptionAttribute != null ? descriptionAttribute.Details : value.ToString();
        }
    }

    internal sealed class EnumMessage : System.Attribute
    {
        /// <summary>
        /// Enum value message.
        /// </summary>
        public string Message { get; }
        /// <summary>
        /// Enum value message.
        /// </summary>
        public string Details { get; }
        /// <summary>
        /// EnumMessage constructor to add the description to the enum value.
        /// </summary>
        /// <param name="message"></param>
        public EnumMessage(string message) => Message = message;
        public EnumMessage(string message, string details)
        {
            Message = message;
            Details = details;



        }
    }
}
