﻿namespace ADPortsEmployee.DTO.Enums
{
    public class SharedEnum
    {
        public enum SortDirection
        {
            Ascending = 0,
            Descending = 1
        }
        public enum ListOperation
        {
            Add = 1,
            Update = 2,
            Remove = 3,

        }
    }
}
