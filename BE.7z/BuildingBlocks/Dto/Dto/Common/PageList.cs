﻿using System.Collections.Generic;

namespace ADPortsEmployee.DTO
{
    public class PageList<T>
    {
        #region Constructor
        public PageList()
        {
            DataList = new List<T>();
        }
        #endregion

        #region Prop
        public List<T> DataList { get; set; }
        public int TotalCount { get; set; }
        #endregion

        #region Methods
        public void SetResult(int totalCount, List<T> dataList)
        {
            TotalCount = totalCount;
            DataList = dataList;
        }

        #endregion
    }
}
