﻿namespace ADPortsEmployee.DTO
{
    public class IdDto
    {
        public int Id { get; set; }
    }
}
