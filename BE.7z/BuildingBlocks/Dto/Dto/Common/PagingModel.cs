﻿namespace ADPortsEmployee.DTO
{
    public class PagingModel
    {
        //public int PageNumber { get; set; }
        public int PageSize { get; set; }

        public int Page { get; set; }
        ///// <summary>
        ///// The list view number.
        ///// </summary>
        //public int Page
        //{
        //    get
        //    {
        //        return _Page;
        //    }
        //    set
        //    {
        //        if (value > 0)
        //            value -= 1;

        //        _Page = value;
        //    }
        //}
        /// <summary>
        /// The list view size.
        /// </summary>
    }
}
