﻿

using static ADPortsEmployee.DTO.Enums.SharedEnum;

namespace ADPortsEmployee.DTO
{
    public class SortingModel
    {
        public string SortingExpression { get; set; }
        public SortDirection SortingDirection { get; set; }


        public string Column { get; set; }

        //private string _Direction;
        //public string Direction
        //{
        //    get
        //    {
        //        return _Direction;
        //    }
        //    set
        //    {
        //        _Direction = value;

        //        if (value == "desc")
        //            SortingDirection = SortDirection.Descending;
        //        else
        //            SortingDirection = SortDirection.Descending;
        //    }
        //}

        ///// <summary>
        ///// The sorting direction.
        ///// <para>Direction should be:</para>
        ///// <para> 0 : Ascending</para>
        ///// <para> 1 : Descending</para>
        ///// </summary>
        //[System.Text.Json.Serialization.JsonIgnore]
        //public SortDirection SortingDirection { get; set; }
    }


}
