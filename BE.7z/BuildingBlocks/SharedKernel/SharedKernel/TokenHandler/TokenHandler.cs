﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Primitives;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Text;

namespace ADPortsEmployee.SharedKernel.TokenHelper
{
    public class TokenHandler
    {
        public IHttpContextAccessor HttpContextAccessor { get; }
        //public TokenSettings TokenSettings { get; }

        public TokenHandler(IHttpContextAccessor httpContextAccessor/*, TokenSettings tokenSettings*/)
        {
            HttpContextAccessor = httpContextAccessor;
            //TokenSettings = tokenSettings; 
        }
        public TokenHandler()
        {

        }
        public long GetUserId()
        {
            long userId = default;

            HttpContextAccessor?.HttpContext?.Request?.Headers?.TryGetValue("Authorization", out StringValues value);
            if (value.Any())
            {
                var header = value.FirstOrDefault().Trim();
                var token = header.Contains("Bearer") ? header.Replace("Bearer ", string.Empty) :
                    header.Trim().Contains("bearer") ? header.Replace("bearer ", string.Empty) :
                    header;
                userId = long.Parse(GetClaim(token, JwtRegisteredClaimNames.Sub));
            }

            return userId;
        }
        public string GenerateToken(long userId, Dictionary<string, object> _claims = null)
        {
            //return GenerateToken(userId, TokenSettings.SecretKey, TokenSettings.Audience, TokenSettings.DurationInMinutes);
            return string.Empty;
        }


        public string GenerateToken(long userId, string secret, string audience, long durationInMinute, string issuer, Dictionary<string, object> _claims = null)
        {

            Dictionary<string, object> claims = new Dictionary<string, object> { { JwtRegisteredClaimNames.Sub, userId } };
            if (_claims?.Any() ?? default)
            {
                foreach (KeyValuePair<string, object> pair in _claims)
                {
                    //this line check for duplicate keys.
                    if (!claims.ContainsKey(pair.Key))
                        //only unique key added in marged dictionary.
                        claims.Add(pair.Key, pair.Value);
                }
            }

            var mySecurityKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(secret));

            var tokenHandler = new JwtSecurityTokenHandler();
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Claims = claims,
                Expires = DateTime.UtcNow.AddMinutes(durationInMinute),
                Issuer = issuer,
                Audience = audience,
                SigningCredentials = new SigningCredentials(mySecurityKey, SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }
        public string GetClaim(string token, string claimType)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var securityToken = new JwtSecurityToken(token);// tokenHandler.ReadToken(token) as JwtSecurityToken;

            var stringClaimValue = securityToken.Claims.First(claim => claim.Type == claimType).Value;
            return stringClaimValue;
        }
        public JwtSecurityToken ExtractToken(string token)
        {
            var handler = new JwtSecurityTokenHandler();
            return handler.ReadJwtToken(token);
        }


    }
}
