﻿using Newtonsoft.Json;
using RestSharp;
using RestSharp.Authenticators;
using Serilog;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace ADPortsEmployee.SharedKernel.GenericApiCall
{


    public class GenericAPICall : IGenericApiCall
    {
        #region Fields

        private IAuthenticator authenticator;
        private string baseURL;
        /*/ public ILogger Logger { get; }*/

        #endregion Fields

        #region Constructors

        public GenericAPICall(/*ILogger logger  /*string baseURL, IAuthenticator authenticator*/)
        {
            // Logger = logger;

            //this.baseURL = baseURL;
            //this.authenticator = authenticator;
        }

        public GenericAPICall(string baseURL, string username, string password)
        {
            this.baseURL = baseURL;
            //authenticator = new RestSharp.Authenticators.HttpBasicAuthenticator(username, password);
        }

        #endregion Constructors

        #region Methods
        public async Task<TResponse> Get<TResponse>(string baseUrl, string endPoint, string auditLogMessage = null)
        {
            this.baseURL = baseUrl;
            return await Execute<Object, TResponse>(Method.GET, endPoint, default, default, default, default, auditLogMessage);
        }
        public async Task<TResponse> Get<TResponse>(string baseUrl, string endPoint, Dictionary<string, object> queryParameters, string auditLogMessage = null)
        {
            this.baseURL = baseUrl;
            return await Execute<Object, TResponse>(Method.GET, endPoint, default, default, queryParameters, default, auditLogMessage);
        }
        public async Task<TResponse> Get<TResponse>(string baseUrl, string endPoint, Dictionary<string, object> headers, Dictionary<string, object> queryParameters, string auditLogMessage = null)
        {
            this.baseURL = baseUrl;
            return await Execute<Object, TResponse>(Method.GET, endPoint, headers, default, queryParameters, default, auditLogMessage);
        }
        public async Task<TResponse> Post<TResponse>(string baseUrl, string endPoint, string auditLogMessage = null)
        {
            this.baseURL = baseUrl;
            return await Execute<Object, TResponse>(Method.POST, endPoint, default, default, default, default, auditLogMessage);
        }
        public async Task<TResponse> Post<TResponse>(string baseUrl, string endPoint, Dictionary<string, object> headers, string auditLogMessage = null)
        {
            this.baseURL = baseUrl;
            return await Execute<Object, TResponse>(Method.POST, endPoint, headers, default, default, default, auditLogMessage);
        }
        public async Task<TResponse> Post<TResponse>(string baseUrl, string endPoint, Dictionary<string, object> headers, Dictionary<string, object> parameter, string auditLogMessage = null)
        {
            this.baseURL = baseUrl;
            return await Execute<Object, TResponse>(Method.POST, endPoint, headers, parameter, default, default, auditLogMessage);
        }
        public async Task<TResponse> Post<TResponse>(string baseUrl, string endPoint, Dictionary<string, object> headers, Dictionary<string, object> parameters, Dictionary<string, object> queryParameters, string auditLogMessage = null)
        {
            this.baseURL = baseUrl;
            return await Execute<Object, TResponse>(Method.POST, endPoint, headers, parameters, queryParameters, default, auditLogMessage);
        }

        public async Task<TResponse> Post<TRequest, TResponse>(string baseUrl, string endPoint, TRequest body, string auditLogMessage = null)
        {
            this.baseURL = baseUrl;
            return await Execute<TRequest, TResponse>(Method.POST, endPoint, default, default, default, body, auditLogMessage);

        }
        public async Task<TResponse> Post<TRequest, TResponse>(string baseUrl, string endPoint, Dictionary<string, object> headers, TRequest body, string auditLogMessage = null)
        {
            this.baseURL = baseUrl;
            return await Execute<TRequest, TResponse>(Method.POST, endPoint, headers, default, default, body, auditLogMessage);

        }
        public async Task<TResponse> Post<TRequest, TResponse>(string baseUrl, string endPoint, Dictionary<string, object> headers, Dictionary<string, object> parameter, TRequest body, string auditLogMessage = null)
        {
            this.baseURL = baseUrl;
            return await Execute<TRequest, TResponse>(Method.POST, endPoint, headers, parameter, default, body, auditLogMessage);
        }
        public async Task<TResponse> Post<TRequest, TResponse>(string baseUrl, string endPoint, Dictionary<string, object> headers, Dictionary<string, object> parameters, Dictionary<string, object> queryParameters, TRequest body, string auditLogMessage = null)
        {
            this.baseURL = baseUrl;
            return await Execute<TRequest, TResponse>(Method.POST, endPoint, headers, parameters, queryParameters, body, auditLogMessage);
        }

        private async Task<TResponse> Execute<TRequest, TResponse>(RestSharp.Method method, string endPoint, Dictionary<string, object> headers, Dictionary<string, object> parameters, Dictionary<string, object> queryParameters, TRequest body, string auditLogMessage = null)
        {
            RestClient client = new RestClient(baseURL);
            RestRequest request = new RestRequest(endPoint, method);
            //client.Authenticator = authenticator;

            #region handle Uploading 
            if (endPoint.Equals("api/Uploader/UploadBase64"))
            {
                var files = (Microsoft.AspNetCore.Http.IFormFile)body;

                using (var ms = new MemoryStream())
                {
                    files.CopyTo(ms);
                    var fileBytes = ms.ToArray();

                    var fileMeme = Uploader.MimeType.GetMimeType(fileBytes, files.FileName);
                    request.AddFile(files.FileName, fileBytes, fileMeme);
                }
            }
            if (endPoint.Equals("api/Request/Upload"))
            {
                var files = (Microsoft.AspNetCore.Http.IFormFile)body;

                using (var ms = new MemoryStream())
                {
                    files.CopyTo(ms);
                    var fileBytes = ms.ToArray();

                    var fileMeme = Uploader.MimeType.GetMimeType(fileBytes, files.FileName);
                    request.AddFile(files.FileName, fileBytes, fileMeme);
                }
            }
            #endregion

            #region HandleDownloading
            //if (endPoint.Equals("Uploader/Download"))
            //{
            //    var files = (Microsoft.AspNetCore.Http.IFormCollection)body;
            //    if (files?.Files.Any() ?? default)
            //    {
            //        foreach (var file in files.Files)
            //        {
            //            using (var ms = new MemoryStream())
            //            {
            //                file.CopyTo(ms);
            //                var fileBytes = ms.ToArray();
            //                request.AddFile(file.FileName, fileBytes, file.ContentType);
            //            }
            //        };
            //    }
            //}
            #endregion

            #region headers
            if (headers?.Any() ?? false)
            {
                foreach (var key in headers.Keys)
                {
                    if (headers[key].GetType().ToString().StartsWith("System.Collections.Generics.List"))
                    {
                        request.AddHeader(key, JsonConvert.SerializeObject(headers[key]));
                    }
                    else
                    {
                        request.AddHeader(key, headers[key].ToString());
                    }
                }
            }
            #endregion

            #region Parameters
            if (parameters?.Any() ?? false)
            {
                foreach (var key in parameters.Keys)
                {
                    request.AddParameter(key, parameters[key]);
                }
            }
            #endregion

            #region query params
            if (queryParameters?.Any() ?? false)
            {
                foreach (var key in queryParameters.Keys)
                {
                    //if (headers[key].GetType().ToString().StartsWith("System.Collections.Generics.List"))
                    //{
                    //    request.AddQueryParameter(key, JsonConvert.SerializeObject(queryParameters[key]));
                    //}
                    //else
                    //{
                    request.AddQueryParameter(key, queryParameters[key].ToString());
                    //}
                }
            }
            #endregion
            #region handle Downloading 
            if (endPoint.Contains("Download"))
            {
                return (TResponse)Convert.ChangeType(client.DownloadData(request), typeof(TResponse));
            }
            #endregion


            #region body
            if (body != null && !endPoint.Contains("Upload"))
            {
                request.AddParameter("application/json", JsonConvert.SerializeObject(body), ParameterType.RequestBody); // http body (model) parameter
            }
            if (body != null && endPoint.Equals("api/Uploader/RequestBatchProcessing"))
            {
                request.AddParameter("application/json", JsonConvert.SerializeObject(body), ParameterType.RequestBody); // http body (model) parameter

            }
            #endregion

            client.Proxy = new WebProxy();

            var response = await client.ExecuteTaskAsync(request);
            Log.Error($"Trying To Execute Request URL : {this.baseURL + endPoint} , Body : {JsonConvert.SerializeObject(request.Body)} , Action: {auditLogMessage}");

            if (response != default && response.Content != default && response.StatusCode == System.Net.HttpStatusCode.OK)

                return JsonConvert.DeserializeObject<TResponse>(response.Content.ToString());


            throw new Exception($"Failed To Call External system , Url {baseURL}{endPoint}, Status Code ={response.StatusDescription} , response = {response.Content}");
        }

        #endregion Methods
    }
}

