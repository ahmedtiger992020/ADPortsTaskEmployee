﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace ADPortsEmployee.SharedKernel.GenericApiCall
{
    public interface IGenericApiCall//<TRequest, TResponse>
    {
        Task<TResponse> Get<TResponse>(string baseUrl, string endPoint, string auditLogMessage = null);
        Task<TResponse> Get<TResponse>(string baseUrl, string endPoint, Dictionary<string, object> queryParameters, string auditLogMessage = null);
        Task<TResponse> Get<TResponse>(string baseUrl, string endPoint, Dictionary<string, object> headers, Dictionary<string, object> queryParameters, string auditLogMessage = null);
        Task<TResponse> Post<TResponse>(string baseUrl, string endPoint, Dictionary<string, object> headers, string auditLogMessage = null);
        Task<TResponse> Post<TResponse>(string baseUrl, string endPoint, Dictionary<string, object> headers, Dictionary<string, object> parameter, string auditLogMessage = null);
        Task<TResponse> Post<TResponse>(string baseUrl, string endPoint, string auditLogMessage = null);
        Task<TResponse> Post<TResponse>(string baseUrl, string endPoint, Dictionary<string, object> headers, Dictionary<string, object> parameters, Dictionary<string, object> queryParameters, string auditLogMessage = null);
        Task<TResponse> Post<TRequest, TResponse>(string baseUrl, string endPoint, TRequest body, string auditLogMessage = null);
        Task<TResponse> Post<TRequest, TResponse>(string baseUrl, string endPoint, Dictionary<string, object> headers, TRequest body, string auditLogMessage = null);
        Task<TResponse> Post<TRequest, TResponse>(string baseUrl, string endPoint, Dictionary<string, object> headers, Dictionary<string, object> parameter, TRequest body, string auditLogMessage = null);
        Task<TResponse> Post<TRequest, TResponse>(string baseUrl, string endPoint, Dictionary<string, object> headers, Dictionary<string, object> parameters, Dictionary<string, object> queryParameters, TRequest body, string auditLogMessage = null);
    }
}
