﻿namespace Dto.Enums
{
    public class SharedEnums
    {
        public enum SortDirection
        {
            Ascending = 0,
            Descending = 1
        }
        public enum Paging
        {
            DefaultPageNumber = 1,
            DefaultPageSize = 10
        }
    }
}
