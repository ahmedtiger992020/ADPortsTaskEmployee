import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { NotFoundComponent } from './module/not-found/not-found.component';
import { AuthGuard } from './shared/guards/auth.guard';
   
const routes: Routes = [
  {
    path: 'employee',
    pathMatch: 'full',
    canActivate: [AuthGuard],
    loadChildren: () => import('./module/employee/employee.module').then(m => m.EmployeeModule)
  },
  {
    path: 'login',
    loadChildren: () => import('../app/pages/auth/auth.module').then(m => m.AuthModule)
  },
  {
    path: '404',
    component: NotFoundComponent
  },
  {
    path: '**',
    redirectTo: 'login'
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      useHash: false,
      preloadingStrategy: PreloadAllModules,
      relativeLinkResolution: 'legacy'
    })
  ],
  exports: [RouterModule]
})

export class AppRoutingModule {
}
