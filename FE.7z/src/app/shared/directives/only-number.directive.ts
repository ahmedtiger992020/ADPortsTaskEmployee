import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export function onlyNumbersValidator(): ValidatorFn {
  var regex = new RegExp('^[0-9]*$');
  return (control: AbstractControl): ValidationErrors | null => {
    const forbidden = !regex.test(control.value);
    return forbidden ? { onlyNumbers: { value: control.value } } : null;
  };
}
export function onlyEnglishValidator(): ValidatorFn {
  var regex = new RegExp('^[a-zA-Z ]*$');
  return (control: AbstractControl): ValidationErrors | null => {
    const forbidden = !regex.test(control.value);
    return forbidden ? { onlyEnglish: { value: control.value } } : null;
  };
}

export function onlyTextValidator(): ValidatorFn {
  var regex = new RegExp('^[a-zA-Z0 ]+$');
  return (control: AbstractControl): ValidationErrors | null => {
    const forbidden = !regex.test(control.value);
    return forbidden ? { onlyText: { value: control.value } } : null;
  };
}
export function onlyTextAndNumberValidator(): ValidatorFn {
  var regex = new RegExp('^[a-zA-Z0-9 ]+$');
  return (control: AbstractControl): ValidationErrors | null => {
    const forbidden = !regex.test(control.value);
    return forbidden ? { onlyTextAndNumber: { value: control.value } } : null;
  };
}
export function onlyDecimalValidator(): ValidatorFn {
  var regex = new RegExp('^[0-9]+(.[0-9]+)?$');
  return (control: AbstractControl): ValidationErrors | null => {
    const forbidden = !regex.test(control.value);
    return forbidden ? { onlyDecimal: { value: control.value } } : null;
  };
}
export function phoneValidator(): ValidatorFn {
  var regex = new RegExp('^(010|011|012|015){1}[0-9]{8}$');
  return (control: AbstractControl): ValidationErrors | null => {
    const forbidden = !regex.test(control.value);
    return forbidden ? { phoneOnly: { value: control.value } } : null;
  };
}

export function taxMask(): ValidatorFn {
  var regex = new RegExp('^(010|011|012|015){1}[0-9]{8}$');
  return (control: AbstractControl): ValidationErrors | null => {
    const forbidden = !regex.test(control.value);
    return forbidden ? { phoneOnly: { value: control.value } } : null;
  };



  
}



  
