import { HttpClient, HttpEvent, HttpEventType, HttpHeaders } from '@angular/common/http';
import { Inject, Injectable, InjectionToken, Optional } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Observable, of } from 'rxjs';
import { routes } from 'src/app/consts';
import { AppConfigService } from '../AppConfigService';
import {  
  saveAs as importedSaveAs  
} from "file-saver"; 
export const API_BASE_URL = new InjectionToken<string>('API_BASE_URL');
@Injectable({
  providedIn: 'root'
})
export class UploadService {
  /**
   *
   */
  private baseUrl: string;
  constructor(private http: HttpClient, private toastr: ToastrService, @Optional() @Inject(API_BASE_URL) baseUrl?: string,
  ) {
    this.baseUrl = AppConfigService.appConfig.ApiBaseUrl//baseUrl !== undefined && baseUrl !== null ? baseUrl : "";
  }

  // UploadFile(docs): Observable<HttpEvent<Object>> {
  //   let header = new HttpHeaders({
  //     // Referer: 'http://localhost:4200',
  //     // Origin: 'http://localhost:4200',
  //     Accept: '*/*',
  //   });
  //   return this.http
  //     .post(this.baseUrl + routes.UploadLOADURL, docs, {
  //       headers: header,
  //       reportProgress: true,
  //       observe: 'events',
  //     })

  // }
  // DownloadFile(fileName, fileIdentifier) {

  //   let url = `${this.baseUrl}${routes.DOWNLOADURL}?fileIdentifier=${fileIdentifier}&fileName=${fileName}`
  //   // var downloadWindow = window.open(
  //   //   url,
  //   //   "_blank"
  //   // );
  //   // downloadWindow.focus(); 
  //   this.http.get(url, {  
  //     responseType: 'blob'  
  // }).subscribe(res=>{
      
  //     importedSaveAs(res, fileName)  
  //   })

  // }
   
}
