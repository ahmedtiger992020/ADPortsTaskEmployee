import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

import { LoginRequestDto, UserServiceProxy } from '../swagger/SwaggerGenerated';
import { routes } from 'src/app/consts';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(private router: Router,
    private authService: UserServiceProxy, private toastr: ToastrService,
  ) { }


  isLoggedIn() {
    return (this.getToken() != null || this.getToken() != "");
  }


  clear() {
    localStorage.clear();

  }

  getToken() {
    return localStorage.getItem('token');
  }



  login(loginInfo) {

    let loginDto = new LoginRequestDto();
    loginDto.userName = loginInfo.userName
    loginDto.password = loginInfo.password
     this.authService.login(loginDto).subscribe(res => {
      
      if (res.isValidResponse) {
        window.localStorage.setItem('token', res.dataList);
        
        window.location.href = `${routes.Employee}`;

      }
      else {
        this.clear();
        window.location.href = `${routes.LOGIN}`;
      }
    })
  }
  logout() {
    if (this.isLoggedIn()) {
      {
        this.clear();
        window.location.href = `${routes.LOGIN}`;
      }
    }
  }
}

