import { ChangeDetectorRef, Component, OnDestroy, ViewChild } from '@angular/core';
import { MediaMatcher } from '@angular/cdk/layout';
import { MatSidenav } from '@angular/material/sidenav';
import * as signalR from '@microsoft/signalr';
import { AppConfigService } from '../AppConfigService';
import { ToastrService } from 'ngx-toastr';
import { getApiBaseUrl } from 'src/app/app.module';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.scss']
})
export class LayoutComponent implements OnDestroy {
  @ViewChild('sidenav') sidenav: MatSidenav;
  public isShowSidebar: boolean;
  public mobileQuery: MediaQueryList;
  private mobileQueryListener: () => void;
 
 
  constructor(changeDetectorRef: ChangeDetectorRef, media: MediaMatcher,private toasterService:ToastrService) {
    
    this.mobileQuery = media.matchMedia('(max-width: 1024px)');
    this.mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this.mobileQueryListener);

    this.isShowSidebar = !this.mobileQuery.matches;
  this.startHub()
  }
  getAccessToken(): string {
    return localStorage.getItem('token');
  }
  
  startHub(){
    const connection = new signalR.HubConnectionBuilder()
      .configureLogging(signalR.LogLevel.Information)
      .withUrl(AppConfigService.appConfig.ApiBaseUrl + '/notify', {
        accessTokenFactory: () => this.getAccessToken(),
        skipNegotiation: true,
        transport: signalR.HttpTransportType.WebSockets
        ,
      }).withAutomaticReconnect()

      .build();

    connection.start().then(function () {
      
      console.log('SignalR Connected!');
    }).catch(function (err) {
      return console.error(err.toString());
    });
       connection.on("BroadcastMessage", data => {
        this.toasterService.success(data)      
    });
     
  }
  public ngOnDestroy(): void {
    this.mobileQuery.removeListener(this.mobileQueryListener);

    this.sidenav.close();
  }
}
