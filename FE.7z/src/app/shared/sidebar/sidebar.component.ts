import { PageActionEnum } from './../../consts/PageActionEnum';
import { Component, OnInit } from '@angular/core';
import { routes } from '../../consts/routes';
import { AuthorizeService } from '../services/Authorize.service';
import { UserServiceProxy } from '../swagger/SwaggerGenerated';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})

export class SidebarComponent implements OnInit {
  public routes: typeof routes = routes;
  public isOpenUiElements = false;
  showDashboard = false;
  showRequest = false;
  showAudit = false;
  showProfile = false;
  constructor(private authorizeService: AuthorizeService, private authService: UserServiceProxy) {

  }
  ngOnInit() {
    // this.checkPrivileges()
    
      this.checkPrivileges();
      

  }

  checkPrivileges() {
  }

  public openUiElements() {
    this.isOpenUiElements = !this.isOpenUiElements;
  }

}
