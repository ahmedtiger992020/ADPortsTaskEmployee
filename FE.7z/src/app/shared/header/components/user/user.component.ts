import { Component, EventEmitter, OnInit, Output } from '@angular/core';
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})
export class UserComponent implements OnInit{ 
  @Output() signOut: EventEmitter<void> = new EventEmitter<void>();
  
  constructor()  {
  }

  ngOnInit() {

   
  }

  public signOutEmit(): void {
    this.signOut.emit();
  }
}
