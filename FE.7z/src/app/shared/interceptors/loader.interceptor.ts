import { Injectable, Inject, Injector } from '@angular/core';
import { HttpHeaders, HttpResponse } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpErrorResponse } from '@angular/common/http';
import { from, Observable, switchMap, throwError } from 'rxjs';
import { LoaderService } from 'src/app/shared/app-loader/loader.service';
import { UserServiceProxy } from '../swagger/SwaggerGenerated';
import { AuthenticationService } from '../guards/authentication.service';
import { routes } from 'src/app/consts';
import { JwtHelperService } from '@auth0/angular-jwt';
import { AppConfigService } from '../AppConfigService';
import { Router } from '@angular/router';

@Injectable({ providedIn: 'root' })
export class LoaderInterceptor implements HttpInterceptor {
  constructor(
    @Inject(Injector) private readonly injector: Injector,
    private loaderService: LoaderService, private router: Router, private userService: AuthenticationService, private jwtHelper: JwtHelperService,
  ) {
  }

  cachedRequest: Promise<any>;

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    if (req.url.includes("api/User/GenerateToken")) {
      return from(this.handle(req, next))
    }



    return from(this.handle(req, next));
  }

  private async handle(req: HttpRequest<any>, next: HttpHandler): Promise<HttpEvent<any>> {
    
    const token: string = await this.userService.getToken();
    if (token) {

      req = req.clone({
        headers: req.headers.set('Authorization', 'Bearer ' + token),
      });
    }

    const headerSettings = req.headers.keys().reduce(
      (acc, cur) => {
        acc[cur] = req.headers.getAll(cur);
        return acc;
      }, {});
    if (!req.url.includes('api/Uploader')) {
      headerSettings['Content-Type'] = 'application/json-patch+json';
    }
 
    this.loaderService.ShowLoader();

    const
      headers = new HttpHeaders(headerSettings),
      newRequest = req.clone({ headers });

    const result = next.handle(newRequest).toPromise().finally(() => {


      this.loaderService.HideLoader();
    })

    return result.catch(async (err) => {
 

      if (err.status === 401) {
        this.toastrService.error("Session timeout")
        window.location.href = `${routes.LOGIN}`
        this.userService.clear()
        return next.handle(req).toPromise();
      }
      else if (err.status === 422) {

        if (err.error instanceof Blob) {
          err.error.text().then(text => {
            error_msg = (JSON.parse(text).message);
            this.toastrService.error(error_msg, '', {
              positionClass: 'toast-top-center',
            });
            this.userService.clear()
            window.location.href = `${routes.LOGIN}`
          });
        }




      }
      else if (err.status === 403) {
        this.router.navigateByUrl("/404")
      }

      else if (err.status === 409) {
        var error_msg;

        if (err.error instanceof Blob) {
          err.error.text().then(text => {
            error_msg = (JSON.parse(text).message);
            // this.spinnerService.hide();
            this.toastrService.error(error_msg, '', {
              positionClass: 'toast-top-center',
            });

          });
        }
      }
      else if (err.status === 500) {
        var error_msg;

        if (err.error instanceof Blob) {
          err.error.text().then(text => {
            error_msg = (JSON.parse(text).message);
            this.toastrService.error(JSON.parse(`{${error_msg.split('= {').pop().split('}')[0]
              }}`).message, '', {
              positionClass: 'toast-top-center',
            });
          });
        }
      }
      else if (err.status === 0) {
        this.toastrService.error("Cannot Connect To" + ' ' + err.statusText + ' ' + err.url, '', {
          positionClass: 'toast-top-center',
        });
        this.userService.clear()
        window.location.href = `${routes.LOGIN}`

      }
    });
  }
  private get toastrService(): ToastrService {
    return this.injector.get(ToastrService);
  }
}
