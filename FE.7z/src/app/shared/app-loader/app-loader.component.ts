// app-loader.component.ts
import { Component, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { LoaderService } from './loader.service';

@Component({
  selector: 'app-loader',
  templateUrl: './app-loader.component.html',
  styleUrls: ['./app-loader.component.scss']
})
export class AppLoaderComponent{
  show: boolean;
  constructor(private _loaderService: LoaderService) {}
  mode = 'indeterminate';
  value = 50;
  color = 'primary';
  
  ngOnInit() {
    this._loaderService.loadState.subscribe(res => {
      this.show = res;
    });
  }

}