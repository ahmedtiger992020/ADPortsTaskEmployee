export enum routes {
  Employee = '/employee',
  LOGIN = '/login',
  AddEditEmployee = "/addEditEmployee",
 }
