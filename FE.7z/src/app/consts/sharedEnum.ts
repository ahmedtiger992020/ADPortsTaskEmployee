export enum Action {
  Approve = 1,
  Declined = 2,
  Submitted = 3,
  ReActive = 4,
  Cancel = 5
}
export enum GroupType {
  Sales = 1,
  AFU = 2,
  POS = 3,
  Bank = 4,
  SalesSuperVisor = 5,
  SalesManager = 6,
  AFUSuperVisor = 7,
  BankFraud = 8,

}
export enum FormType {
  Owner = 1,
  Attachment = 2,
  Settlement= 3
}
export enum ChannelType {
  Pos = 1,
  eCom = 2,
 }

 export enum StepAction {
  AFUWithApprove = 7,
  BankCompliancePending=16,
  BankFraudPending=17,
  BankWithApprove=9
 }