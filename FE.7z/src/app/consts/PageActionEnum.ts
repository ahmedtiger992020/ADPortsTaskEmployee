export enum PageActionEnum {
  ViewDashboard = 1,
  ViewRequest = 2,
  AddRequest = 3,
  ExportRequest=6,
  ViewProfile =7,
  ExportXML =8,
  ShowAudit =9,
  BankDownload =10,
  UploadBatchBank =11,

//   EditRequest = 4,
//   DeleteRequest = 5,
}