import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTabsModule } from '@angular/material/tabs';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { AuthRoutingModule } from './auth-routing.module';
import { AuthGuard } from 'src/app/shared/guards';
import { YearPipe } from 'src/app/shared/pipes';
 import { LoginFormComponent } from './components/login-form/login-form.component';
import { AuthPageComponent } from './containers/auth-page/auth-page.component';
import { AuthenticationService } from 'src/app/shared/guards/authentication.service';
import { MatCardModule } from '@angular/material/card';
import { MatIcon, MatIconModule } from '@angular/material/icon';

@NgModule({
  declarations: [
    AuthPageComponent,
    YearPipe,
    LoginFormComponent,
  ],
  imports: [
    CommonModule,
    AuthRoutingModule,
    MatTabsModule,
    MatButtonModule,
    MatInputModule,
    ReactiveFormsModule,
    FormsModule,
    MatCardModule,MatIconModule
  ],
  providers: [
    AuthenticationService,
    AuthGuard
  ]
})
export class AuthModule { }
