import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AuthenticationService } from 'src/app/shared/guards/authentication.service';
import { LoginRequestDto } from 'src/app/shared/swagger/SwaggerGenerated';

@Component({
  selector: 'app-login-form',
  templateUrl: './login-form.component.html',
  styleUrls: ['./login-form.component.scss']
})
export class LoginFormComponent implements OnInit {
  @Output() sendLoginForm = new EventEmitter<void>();
  public form: FormGroup;
  hide: any;
  PasswordTextType: string;
  public loginForm: FormGroup;

  constructor(private authService: AuthenticationService) {


  }
  public ngOnInit() {
    this.loginForm = new FormGroup({
      userName: new FormControl('', [Validators.required]),
      password: new FormControl('', [Validators.required]),

    });

  }

  public login(): void {


    this.authService.login({
      userName: this.loginForm.get('userName').value,
      password: this.loginForm.get('password').value,
    } as LoginRequestDto);


    // this.sendLoginForm.emit();

  }
  public TogglePasswrd(): void {
    if (this.hide) {
      this.PasswordTextType = 'text';
    } else {
      this.PasswordTextType = 'password';
    }

    this.hide = !this.hide;
  }
}
