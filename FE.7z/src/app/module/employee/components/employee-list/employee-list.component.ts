import { routes } from '../../../../consts/routes';
import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatExpansionPanel } from '@angular/material/expansion';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { Router } from '@angular/router';
import { merge, startWith, switchMap, map, Subject } from 'rxjs';
import { BaseComponent } from 'src/app/module/base.component';
import { TableUtil } from 'src/app/shared/services/tableUtil';
 import { Utils } from '../../models/paging';
import { ToastrService } from 'ngx-toastr';
import { EmployeeServiceProxy, GetAllEmployeeInputDto, GetAllEmployeeOutputDto } from 'src/app/shared/swagger/SwaggerGenerated';
@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css'],
})
export class EmployeeListComponent extends BaseComponent implements OnInit, AfterViewInit {
  @ViewChild('panel1') firstPanel: MatExpansionPanel;

  spinnerEnabled = false;
  dataSheet = new Subject();
  @ViewChild('inputFile') inputFile: ElementRef;

  public toggleFirstPanel() {
    this.firstPanel.toggle();
  }
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  resultsLength = 0;
  dataSource: any;
  displayedColumns: string[] = ['Name', 'Address', 'Contact', 'SubmissionDate', 'symbol'];
  displayedfilter: string[] = [];
  filterValues = {};
  filterSelectObj = [];
  Filters: boolean = false;
  defualtPageSize: number = Utils.DEFUALT_PAGE_SIZE;
  searchDto = {
    paging: {
      page: Utils.DEFUALT_PAGE_NUMBER,
      pageSize: Utils.DEFUALT_PAGE_SIZE
    },
    sortingModel: {
      sortingExpression: "",
      sortingDirection: 0
    },
    name: "",
    address: "",
    contact: "",
    dateFrom: "",
    dateTo: ""
  }


  constructor( 
    private toastr: ToastrService,
     private router: Router, public dialog: MatDialog,private employeeService:EmployeeServiceProxy) {
    super()

  }




  ngOnInit() {

  }

  ngAfterViewInit() {

    this.loadData();

  }
  applyFilter(event: Event) {
    // const filterValue = (event.target as HTMLInputElement).value;
    // this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  resetSearch() {
    this.searchDto = {
      paging: {
        page: Utils.DEFUALT_PAGE_NUMBER,
        pageSize: Utils.DEFUALT_PAGE_SIZE
      },
      sortingModel: {
        sortingExpression: "",
        sortingDirection: 0
      },
      name: "",
      address: "",
      contact: "",
      dateFrom: "",
      dateTo: ""

    }
    this.loadData()
  }



  exportTable() {
    const onlyNameAndSymbolArr: Partial<GetAllEmployeeOutputDto>[] = this.dataSource.map(x => ({
      EmployeeName: x.name,
      Address: x.address,
      Manager: x.manager,
      Contact: x.contact,
      CreatedDate: x.createdDate,
      }));


    TableUtil.exportArrayToExcel(onlyNameAndSymbolArr, "EmployeeList");
  }
  hideExp: boolean = false;
  hideExport() {
    if (this.dataSource) {
      this.hideExp == false
    } else {
      this.hideExp = true
    }

  }

  loadData() {

    this.sort.sortChange.subscribe(() => (this.paginator.pageIndex = 0));
    merge(this.sort.sortChange, this.paginator.page)
      .pipe(
        startWith({}),
        switchMap(() => {

          this.prepareSearchObject(this.paginator, this.sort, this.searchDto);

          return this.employeeService.getAllEmployee(this.searchDto as GetAllEmployeeInputDto);
        }),
        map((data) => {
          // Flip flag to show that loading has finished.
          console.log(data);

          return data;
        }),
      )
      .subscribe((data) => {


        this.dataSource = data.dataList;
        this.resultsLength = data.totalCount;

      });
  }

  public navigateToAddEditPage(employeeId) {

     this.router.navigateByUrl(`${routes.AddEditEmployee}/${employeeId}`,
      { skipLocationChange: true });



  }
 

  DeleteEmployee(id) {
    this.employeeService.deleteEmployee(id)
      .subscribe((data) => {
        if (data.isValidResponse && data.dataList) {
          this.toastr.success(
            "Info",
            data.commandMessage)
          this.router.navigateByUrl(`/employee`);
        }
        else
          this.toastr.success(
            "error",
            data.commandMessage)
      })
  }
  @ViewChild('empTbSort') empTbSort = new MatSort();
  @ViewChild('empTbSortWithObject') empTbSortWithObject = new MatSort();

}

