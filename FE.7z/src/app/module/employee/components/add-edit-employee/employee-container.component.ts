import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { BaseComponent } from 'src/app/module/base.component';

import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';

import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { HttpClient } from '@angular/common/http';
import { MatDialog } from '@angular/material/dialog';
import { Subject } from 'rxjs';
import { MatSelect } from '@angular/material/select';
import { CreateEmployeeDto, EmployeeServiceProxy, UpdateEmployeeDto } from 'src/app/shared/swagger/SwaggerGenerated';

@Component({
  selector: 'app-employee-container',
  templateUrl: './employee-container.component.html',
  styleUrls: ['./employee-container.component.css'],
})

export class EmployeeContainerComponent extends BaseComponent implements OnInit, OnDestroy {
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  form: FormGroup;

  fileExt = "image/png, image/jpeg, application/pdf"

  dataSource = new MatTableDataSource<any>();

  employeeId: number;
  public progress: number;


  /** list of banks filtered by search keyword */

  @ViewChild('singleSelect', { static: true }) singleSelect: MatSelect;
  /** Subject that emits when the component has been destroyed. */
  protected _onDestroy = new Subject<void>();
  readOnly: boolean;
  constructor(private http: HttpClient,
    public dialog: MatDialog,
    private toastr: ToastrService,
    private router: Router,
    private route: ActivatedRoute,
    private fb: FormBuilder,
    private employeeService: EmployeeServiceProxy,

  ) {

    super();

  }
  backToList() {
    setTimeout(() => {
      this.router.navigateByUrl(`/employee`);
    }, 200);
  }
  readQueryParams() {
    this.route.paramMap.subscribe((params) => {
      if (params.get('employeeId') != null) {
        this.employeeId = parseInt(params.get('employeeId'));
         if (this.employeeId) this.loadData(Number(this.employeeId));
      }
    });
  }

  loadData(employeeId: number) {
    
    if (this.employeeId) {

      this.employeeService.getEmployeeById(employeeId).subscribe((res) => {
        if (res.isValidResponse) {
          this.form.patchValue(res.dataList);
        }
      });
    }
  }
  findInvalidControls = () => {
    const invalid = [];
    const controls = this.form.controls;
    for (const name in controls) {
      if (controls[name].invalid) {
        invalid.push(name);
      }
    }
    return invalid;
  };

  name = '';

  ngOnInit() {

    this.readQueryParams();

    this.form = this.fb.group({
      name: new FormControl('', [Validators.required]),
      address: new FormControl('', [Validators.required]),
      manager: new FormControl('', [Validators.required]),
      contact: new FormControl('', [Validators.required]),

    });

    this.form.valueChanges.subscribe(value => {
      console.log('name has changed:', value)
      console.log('findInvalidControls', this.findInvalidControls());
    });
  }


  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }



  onSubmit() {

    if (this.employeeId > 0) {
      
       var updateRequestDto = this.form.value as UpdateEmployeeDto;
       updateRequestDto.id = this.employeeId
       updateRequestDto.manager = this.form.value.manager
       updateRequestDto.contact =  this.form.value.contact
       updateRequestDto.name = this.form.value.name

      this.employeeService.updateEmployee(updateRequestDto).subscribe((data) => {
        if (data.isValidResponse) {
          this.toastr.success('Info', 'Employee Updated Successfully');
          this.router.navigateByUrl('employee');
        }
      });
    } else {

      var createRequestDto = this.form.value as CreateEmployeeDto;
      this.employeeService.createEmployee(createRequestDto).subscribe((data) => {
        if (data.isValidResponse) {
          this.toastr.success('Info', 'Employee Added Successfully');

          this.router.navigateByUrl('employee');
        }
      });
    }
  }

}

