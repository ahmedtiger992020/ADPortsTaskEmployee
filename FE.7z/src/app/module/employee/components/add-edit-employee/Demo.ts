export class CreateRequest {
    id?: number;
    legalName?: string | undefined;
    commercialName?: string | undefined;
    cbeSegmentId?: number;
    mccId?: number;
    contactPerson?: string | undefined;
    contactPersonPhone?: string | undefined;
    website?: string | undefined;
    merchantActivityDescription?: string | undefined;
    taxId?: string | undefined;
    commercialNumber?: string | undefined;
    address?: string | undefined;
    cityId?: number;
}