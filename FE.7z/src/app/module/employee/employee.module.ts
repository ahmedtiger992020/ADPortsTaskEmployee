import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { TrendModule } from 'ngx-trend';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatButtonModule } from '@angular/material/button';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';
import { MatStepperModule } from '@angular/material/stepper';
import { MatButtonToggleModule } from '@angular/material/button-toggle';

import { MatCheckboxModule } from '@angular/material/checkbox';
import { RouterModule, Routes } from '@angular/router';
import { FormlyBootstrapModule } from '@ngx-formly/bootstrap';
import { HttpClientModule } from '@angular/common/http';
import { MatNativeDateModule } from '@angular/material/core';
import { MatFormFieldDefaultOptions, MAT_FORM_FIELD_DEFAULT_OPTIONS } from '@angular/material/form-field';
import { MatSortModule } from '@angular/material/sort';
import { MatPaginatorModule } from '@angular/material/paginator';
import { NgxFormProgressBarModule } from 'ngx-form-progress-bar';
// import { NgxFormProgressBarModule } from 'ngx-form-progress-bar';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatDividerModule } from '@angular/material/divider';
import { MatRadioModule } from '@angular/material/radio';
import { MatTabsModule } from '@angular/material/tabs';

 import { MatDialogModule } from '@angular/material/dialog';
import { UploadService } from 'src/app/shared/services/upload.service';
import { AuthorizeService } from 'src/app/shared/services/Authorize.service';
import { TranslateService } from 'src/app/shared/services/translate.service';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { EmployeeListComponent } from './components/employee-list/employee-list.component';
import { EmployeeContainerComponent } from './components/add-edit-employee/employee-container.component';
import { EmployeeServiceProxy } from 'src/app/shared/swagger/SwaggerGenerated';
const routes: Routes = [
  {
    path: 'employee',
    component: EmployeeListComponent
  },
  {

    path: 'addEditEmployee/:employeeId',
    component: EmployeeContainerComponent
  }

];
const appearance: MatFormFieldDefaultOptions = {
  appearance: 'legacy'
};

@NgModule({
  declarations: [
    EmployeeListComponent,
    EmployeeContainerComponent
  ],
  imports: [

    RouterModule.forChild(routes),
    MatAutocompleteModule,
    CommonModule,
    NgxMatSelectSearchModule,
    MatTabsModule,
    MatTableModule,
     MatRadioModule,
    TrendModule,
    MatCardModule, MatPaginatorModule, MatSortModule, MatDialogModule,
    MatTableModule,
    MatNativeDateModule,
    HttpClientModule,
    MatStepperModule
    , MatDialogModule,
    MatIconModule,
    MatButtonToggleModule,
    MatStepperModule,
    MatMenuModule,
    MatButtonModule,
    MatCheckboxModule,
    MatProgressBarModule,
    
    MatToolbarModule,MatDividerModule,
    FormlyBootstrapModule,
    MatNativeDateModule,
    MatDatepickerModule,
    MatExpansionModule,
    MatGridListModule,
    MatSelectModule,
    MatButtonModule,
    NgxFormProgressBarModule,
    MatInputModule,
    // NgApexchartsModule,
    FormsModule,
    SharedModule,
    
     ReactiveFormsModule,
    // TranslateModule.forRoot()
  ],
  exports: [
  ],
  providers: [
    {
      provide: MAT_FORM_FIELD_DEFAULT_OPTIONS,
      useValue: appearance
    },
     EmployeeServiceProxy,// ... other providers like services,
    UploadService,
    AuthorizeService,TranslateService 
  ], 

})
export class EmployeeModule { }
