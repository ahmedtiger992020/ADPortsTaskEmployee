export class Sorting{
    sortingExpression?: string = "";
    sortingDirection?: number = 0;
}
export enum SortingDirectionEnum{
    Ascending = 0,
    Descending = 1
  }