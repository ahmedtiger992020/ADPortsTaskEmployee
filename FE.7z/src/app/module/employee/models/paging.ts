

export class Paging {
    pageNumber?: number = Utils.DEFUALT_PAGE_NUMBER;
    pageSize?: number = Utils.DEFUALT_PAGE_SIZE;
}


export class Utils {
    public static readonly DEFUALT_PAGE_SIZE = 10;
    public static readonly DEFUALT_PAGE_NUMBER = 1;
    public static readonly MAX_PAGE_SIZE = 1000;
}