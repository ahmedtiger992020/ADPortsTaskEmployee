import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { ToastrModule } from 'ngx-toastr';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';

import { AppComponent } from './app.component';
import { SharedModule } from './shared/shared.module';
import { AppRoutingModule } from './app-routing.module';
import { NotFoundComponent } from './module/not-found/not-found.component';
import { AppConfigService } from './shared/AppConfigService';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { LoaderInterceptor } from './shared/interceptors/loader.interceptor';
import { API_BASE_URL, UserServiceProxy } from './shared/swagger/SwaggerGenerated';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { AppLoaderComponent } from './shared/app-loader/app-loader.component';
import { LoaderService } from './shared/app-loader/loader.service';
import { NgxWebstorageModule } from 'ngx-webstorage';
import { CurrencyPipe } from '@angular/common';
import { UploadService } from './shared/services/upload.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatSelectModule } from '@angular/material/select';
import { AuthorizeService } from './shared/services/Authorize.service';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { JwtModule } from '@auth0/angular-jwt';
import { AuthGuard } from './shared/guards';
import { AuthModule } from './pages/auth/auth.module';
import { TranslateService } from './shared/services/translate.service';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatTableModule } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatSortModule } from '@angular/material/sort';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { EmployeeModule } from './module/employee/employee.module';

export function getApiBaseUrl(): string {
  return AppConfigService.appConfig.ApiBaseUrl;
}
@NgModule({
  declarations: [
    AppComponent,
    NotFoundComponent,
    AppLoaderComponent,


  ],
  imports: [
    BrowserModule,
    FormsModule, AuthModule, MatSortModule,
    MatDatepickerModule, MatNativeDateModule,
    MatSelectModule, MatTableModule, MatIconModule,
    SharedModule,
    EmployeeModule,
    MatPaginatorModule,
    BrowserAnimationsModule, MatExpansionModule,
    RouterModule,
    AppRoutingModule,
    ToastrModule.forRoot(),
    NgxWebstorageModule.forRoot(),
    JwtModule.forRoot({
      config: {
        tokenGetter: () => {
          return localStorage.getItem('token');
        }
      }
    }),
    FormsModule,
    ReactiveFormsModule,
    MatCardModule, MatFormFieldModule,
    MatInputModule,
    HttpClientModule,
    MatProgressSpinnerModule,
    MatButtonModule,

  ],
  providers: [CurrencyPipe, LoaderService, UploadService, { provide: API_BASE_URL, useFactory: getApiBaseUrl },
    { provide: HTTP_INTERCEPTORS, useClass: LoaderInterceptor, multi: true },
    AuthorizeService,
    UserServiceProxy, AuthGuard, TranslateService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
