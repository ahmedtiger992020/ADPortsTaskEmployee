import { Component, EventEmitter, HostListener, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
 import { routes } from './consts';
 import { AuthenticationService } from './shared/guards/authentication.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
 

  constructor(
    private authService: AuthenticationService,
    private router: Router
  ) {

  }
  ngOnInit() {
  }

  logOut() {
    this.authService.logout();
    this.router.navigateByUrl(`${routes.LOGIN}`)
  }

}
